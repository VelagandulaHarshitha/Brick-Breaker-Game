package demogame;

import javax.swing.JFrame;

public class MainClass {

	public static void main(String[] args) {
       JFrame f=new JFrame();
       GamePlay gamePlay=new GamePlay();
       f.setTitle("Brick Breaker");
       f.setBounds(10,10,700,600);
       f.setVisible(true);
       f.setResizable(false);
       f.setVisible(true);
       f.setResizable(false);
       f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
       f.add(gamePlay);
     }

}
